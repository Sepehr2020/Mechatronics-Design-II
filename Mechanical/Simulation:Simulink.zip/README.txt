1. To run, open up file of each of the different design
	Design 1: Frame.slx
	Design 2: throwingarmproject.slx
	Design 3: Fixed.slx
2. If you haven't already add the folder of the designs into the matlab path, otherwise you will get error in which the files will not run and say files are missing
3. All the files were orginially created in the MATLAB 2020b Version, if you have any errors regarding version control, Matlab 2020a versions have been saved.
	a) In case 2020a version is needed, it uses the same file name as before but at the end it inculudes the follwing "2020a", ex Frame2020a.slx