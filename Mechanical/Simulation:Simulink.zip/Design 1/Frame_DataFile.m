% Simscape(TM) Multibody(TM) version: 7.2

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(56).translation = [0.0 0.0 0.0];
smiData.RigidTransform(56).angle = 0.0;
smiData.RigidTransform(56).axis = [0.0 0.0 0.0];
smiData.RigidTransform(56).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [154.24365847718823 94.337622286599654 4.9999999999999991];  % mm
smiData.RigidTransform(1).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(1).axis = [1 0 0];
smiData.RigidTransform(1).ID = 'B[tunnel-1:-:tunnel-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [154.24365847718821 94.33762228659964 -40];  % mm
smiData.RigidTransform(2).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(2).axis = [-1 9.4368957093138306e-16 0];
smiData.RigidTransform(2).ID = 'F[tunnel-1:-:tunnel-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [154.24365847718823 94.337622286599654 4.9999999999999991];  % mm
smiData.RigidTransform(3).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(3).axis = [1 0 0];
smiData.RigidTransform(3).ID = 'B[tunnel-1:-:Wheel-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-44.999999999997165 -89.997274540088739 66.168506552058005];  % mm
smiData.RigidTransform(4).angle = 1.8213167324452859;  % rad
smiData.RigidTransform(4).axis = [-0.44571176099581561 -0.77632599609958841 0.44571176099581505];
smiData.RigidTransform(4).ID = 'F[tunnel-1:-:Wheel-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [154.24365847718823 94.337622286599654 0];  % mm
smiData.RigidTransform(5).angle = 0;  % rad
smiData.RigidTransform(5).axis = [0 0 0];
smiData.RigidTransform(5).ID = 'B[tunnel-1:-:item_0037003_Profile_5_20x20_L=10-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [11.649024174328275 -4.9999999999956941 -94.627166424589092];  % mm
smiData.RigidTransform(6).angle = 1.6828632789468103;  % rad
smiData.RigidTransform(6).axis = [-0.89377405898020768 0.31714975287239705 0.31714975287239588];
smiData.RigidTransform(6).ID = 'F[tunnel-1:-:item_0037003_Profile_5_20x20_L=10-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [-8.0000000000000071 9.9999999999999982 7.9999999999999929];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[item_0037003_Profile_5_20x20_L=60-6:-:tunnel-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [56.910330263485662 217.09911096162671 14.999999999996856];  % mm
smiData.RigidTransform(8).angle = 3.1415926535897887;  % rad
smiData.RigidTransform(8).axis = [-0.90286227862402069 -0.42992988479267324 -8.9208869140604981e-16];
smiData.RigidTransform(8).ID = 'F[item_0037003_Profile_5_20x20_L=60-6:-:tunnel-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [13.025865914055078 119.97413408594905 5];  % mm
smiData.RigidTransform(9).angle = 0;  % rad
smiData.RigidTransform(9).axis = [0 0 0];
smiData.RigidTransform(9).ID = 'B[wall-1:-:shaft-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [1.4210854715202004e-14 3.694822225952521e-13 4.9999999999999982];  % mm
smiData.RigidTransform(10).angle = 0;  % rad
smiData.RigidTransform(10).axis = [0 0 0];
smiData.RigidTransform(10).ID = 'F[wall-1:-:shaft-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [99.999999999999972 33.000000000003276 0];  % mm
smiData.RigidTransform(11).angle = 0;  % rad
smiData.RigidTransform(11).axis = [0 0 0];
smiData.RigidTransform(11).ID = 'B[wall-1:-:shaft-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [3.5154593171561199e-14 3.7576705500302698e-13 -1.7763568394002505e-15];  % mm
smiData.RigidTransform(12).angle = 0;  % rad
smiData.RigidTransform(12).axis = [0 0 0];
smiData.RigidTransform(12).ID = 'F[wall-1:-:shaft-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [0 10.000000000000002 -10];  % mm
smiData.RigidTransform(13).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(13).axis = [1 0 0];
smiData.RigidTransform(13).ID = 'B[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=300-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-80.000000000000014 9.9999999999999982 -10];  % mm
smiData.RigidTransform(14).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(14).axis = [1 0 0];
smiData.RigidTransform(14).ID = 'F[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=300-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [0 10.000000000000002 -10];  % mm
smiData.RigidTransform(15).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(15).axis = [1 0 0];
smiData.RigidTransform(15).ID = 'B[item_0037003_Profile_5_20x20_L=300-1:-:]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-20 0 -10.000000000000009];  % mm
smiData.RigidTransform(16).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(16).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(16).ID = 'F[item_0037003_Profile_5_20x20_L=300-1:-:]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [0 10.000000000000002 -10];  % mm
smiData.RigidTransform(17).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(17).axis = [1 0 0];
smiData.RigidTransform(17).ID = 'B[item_0037003_Profile_5_20x20_L=300-1:-:wall-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [110 0 2.5999999999999925];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(18).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(18).ID = 'F[item_0037003_Profile_5_20x20_L=300-1:-:wall-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [-10.000000000000002 10.000000000000002 0];  % mm
smiData.RigidTransform(19).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(19).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(19).ID = 'B[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_180-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [270.00000000000011 -20.000000000001009 -9.9999999999990123];  % mm
smiData.RigidTransform(20).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(20).axis = [1 0 0];
smiData.RigidTransform(20).ID = 'F[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_180-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [0 10 -10];  % mm
smiData.RigidTransform(21).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(21).axis = [1 0 0];
smiData.RigidTransform(21).ID = 'B[item_0037003_Profile_5_20x20_L=300-2:-:wall-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [109.99999999999042 1.7763568394002505e-15 2.3999999999909249];  % mm
smiData.RigidTransform(22).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(22).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(22).ID = 'F[item_0037003_Profile_5_20x20_L=300-2:-:wall-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [9.9999999999999947 10 0];  % mm
smiData.RigidTransform(23).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(23).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(23).ID = 'B[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_180-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [270.00000000000011 -20 9.9999999999999858];  % mm
smiData.RigidTransform(24).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(24).axis = [0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(24).ID = 'F[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_180-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [0 0 0];  % mm
smiData.RigidTransform(25).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(25).axis = [0.57735026918962573 0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(25).ID = 'B[Wheel-1:-:ball-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [56.311048083902079 -31.325571199859731 15.789578881669723];  % mm
smiData.RigidTransform(26).angle = 0.43497685546132492;  % rad
smiData.RigidTransform(26).axis = [-0.043968355551033608 0.4827504481696489 0.87465352483262826];
smiData.RigidTransform(26).ID = 'F[Wheel-1:-:ball-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [0 0 0];  % mm
smiData.RigidTransform(27).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(27).axis = [0.57735026918962573 0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(27).ID = 'B[Wheel-3:-:ball-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [-46.364586855535904 34.204661036474555 32.892287814331681];  % mm
smiData.RigidTransform(28).angle = 1.9600634664585288;  % rad
smiData.RigidTransform(28).axis = [0.080610823026435588 0.096766110070788766 0.9920374061257814];
smiData.RigidTransform(28).ID = 'F[Wheel-3:-:ball-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [-50 0 0];  % mm
smiData.RigidTransform(29).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(29).axis = [-0.57735026918962573 -0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(29).ID = 'B[Wheel-1:-:Wheel-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [-50.000000000000057 -99.251807179588951 -72.65038727760296];  % mm
smiData.RigidTransform(30).angle = 3.1415926535897909;  % rad
smiData.RigidTransform(30).axis = [-0.70710678118654735 -1.2834403885108224e-15 0.70710678118654779];
smiData.RigidTransform(30).ID = 'F[Wheel-1:-:Wheel-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [-50 0 0];  % mm
smiData.RigidTransform(31).angle = 1.7769261774680689;  % rad
smiData.RigidTransform(31).axis = [-0.41218851360286374 -0.4121885136028639 -0.81252769707113592];
smiData.RigidTransform(31).ID = 'B[Wheel-1:-:wall-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [100.00000000000955 33.000000000003276 17.600000000001657];  % mm
smiData.RigidTransform(32).angle = 2.5935642459694805;  % rad
smiData.RigidTransform(32).axis = [0.2810846377148209 0.678598344545847 0.67859834454584678];
smiData.RigidTransform(32).ID = 'F[Wheel-1:-:wall-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [0 0 0];  % mm
smiData.RigidTransform(33).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(33).axis = [0.57735026918962573 0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(33).ID = 'B[Wheel-1:-:wall-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [99.999999999999972 33.000000000003276 -12.600000000007405];  % mm
smiData.RigidTransform(34).angle = 0.15352962984117713;  % rad
smiData.RigidTransform(34).axis = [1.08576517418997e-15 4.7049824214898701e-15 1];
smiData.RigidTransform(34).ID = 'F[Wheel-1:-:wall-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [3.3000000001000007 110.57999999999998 -9.1999999998999957];  % mm
smiData.RigidTransform(35).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(35).axis = [1 0 0];
smiData.RigidTransform(35).ID = 'B[item_0037003_Profile_5_20x20_180-1:-:item_0037003_Profile_5_20x20_180-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [3.3000000000999989 110.57999999999898 70.800000000101022];  % mm
smiData.RigidTransform(36).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(36).axis = [-1 0 0];
smiData.RigidTransform(36).ID = 'F[item_0037003_Profile_5_20x20_180-1:-:item_0037003_Profile_5_20x20_180-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [0 10 -10];  % mm
smiData.RigidTransform(37).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(37).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(37).ID = 'B[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_L=10-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [120.70666583280956 9.9999999999999858 -10.000000000000249];  % mm
smiData.RigidTransform(38).angle = 1.5707963267948966;  % rad
smiData.RigidTransform(38).axis = [-1.8056063274863413e-15 -1 1.8056063274863413e-15];
smiData.RigidTransform(38).ID = 'F[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_L=10-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [-10.000000000000009 10.000000000000009 0];  % mm
smiData.RigidTransform(39).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(39).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(39).ID = 'B[item_0037003_Profile_5_20x20_L=10-3:-:item_0037003_Profile_5_20x20_L=10-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [-10.000000000000028 60.000000000000092 -1.4210854715202004e-13];  % mm
smiData.RigidTransform(40).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(40).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(40).ID = 'F[item_0037003_Profile_5_20x20_L=10-3:-:item_0037003_Profile_5_20x20_L=10-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [10 10.000000000000002 0];  % mm
smiData.RigidTransform(41).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(41).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(41).ID = 'B[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=10-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [120.70666583280953 -9.9999999999998952 -1.3855583347321954e-13];  % mm
smiData.RigidTransform(42).angle = 1.5707963267948966;  % rad
smiData.RigidTransform(42).axis = [-1.8056063274863413e-15 -1 1.8056063274863413e-15];
smiData.RigidTransform(42).ID = 'F[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=10-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [10 10.000000000000002 0];  % mm
smiData.RigidTransform(43).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(43).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(43).ID = 'B[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=60-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [10.00000000000003 -10.000000000000044 7.1054273576010019e-14];  % mm
smiData.RigidTransform(44).angle = 1.570796326794893;  % rad
smiData.RigidTransform(44).axis = [-1 -0 -3.4914813388431334e-15];
smiData.RigidTransform(44).ID = 'F[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=60-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [-10.000000000000002 10 0];  % mm
smiData.RigidTransform(45).angle = 0;  % rad
smiData.RigidTransform(45).axis = [0 0 0];
smiData.RigidTransform(45).ID = 'B[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_L=60-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [10.00000000000024 49.999999999999964 2.8421709430404007e-13];  % mm
smiData.RigidTransform(46).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(46).axis = [-0.70710678118654879 -0.70710678118654635 -2.4980018054066022e-15];
smiData.RigidTransform(46).ID = 'F[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_L=60-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [0 0 0];  % mm
smiData.RigidTransform(47).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(47).axis = [0.57735026918962573 0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(47).ID = 'B[Wheel-1:-:item_0037003_Profile_5_20x20_L=60-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [19.999999999990521 45.00000000000145 43.000000000003574];  % mm
smiData.RigidTransform(48).angle = 3.0330841776553061;  % rad
smiData.RigidTransform(48).axis = [-0.054307533572632079 -0.70606327329682494 -0.7060632732968275];
smiData.RigidTransform(48).ID = 'F[Wheel-1:-:item_0037003_Profile_5_20x20_L=60-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [10 10.000000000000002 0];  % mm
smiData.RigidTransform(49).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(49).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(49).ID = 'B[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=60-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [-270.00000000000006 -10.000000000000046 7.1054273576010019e-14];  % mm
smiData.RigidTransform(50).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(50).axis = [-0.57735026918962584 -0.57735026918962373 -0.57735026918962784];
smiData.RigidTransform(50).ID = 'F[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=60-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(51).translation = [0 10 -10];  % mm
smiData.RigidTransform(51).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(51).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(51).ID = 'B[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_L=60-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(52).translation = [-269.99999999999983 59.999999999999929 10.000000000000327];  % mm
smiData.RigidTransform(52).angle = 1.570796326794893;  % rad
smiData.RigidTransform(52).axis = [-1 -0 -3.4914813388431334e-15];
smiData.RigidTransform(52).ID = 'F[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_L=60-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(53).translation = [9.9999999999999538 10.000000000000002 0];  % mm
smiData.RigidTransform(53).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(53).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(53).ID = 'B[item_0037003_Profile_5_20x20_L=60-3:-:item_0037003_Profile_5_20x20_180-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(54).translation = [-9.9999999999998863 -20.000000000001123 -49.999999999998998];  % mm
smiData.RigidTransform(54).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(54).axis = [-0.57735026918962384 -0.57735026918962584 0.57735026918962762];
smiData.RigidTransform(54).ID = 'F[item_0037003_Profile_5_20x20_L=60-3:-:item_0037003_Profile_5_20x20_180-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(55).translation = [0 10.000000000000002 10];  % mm
smiData.RigidTransform(55).angle = 0;  % rad
smiData.RigidTransform(55).axis = [0 0 0];
smiData.RigidTransform(55).ID = 'B[item_0037003_Profile_5_20x20_180-2:-:item_0037003_Profile_5_20x20_L=60-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(56).translation = [-5.9716946880883793e-14 -10.000000000002061 -90.57999999999798];  % mm
smiData.RigidTransform(56).angle = 3.1415926535897882;  % rad
smiData.RigidTransform(56).axis = [0 0.70710678118654624 0.70710678118654879];
smiData.RigidTransform(56).ID = 'F[item_0037003_Profile_5_20x20_180-2:-:item_0037003_Profile_5_20x20_L=60-6]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(9).mass = 0.0;
smiData.Solid(9).CoM = [0.0 0.0 0.0];
smiData.Solid(9).MoI = [0.0 0.0 0.0];
smiData.Solid(9).PoI = [0.0 0.0 0.0];
smiData.Solid(9).color = [0.0 0.0 0.0];
smiData.Solid(9).opacity = 0.0;
smiData.Solid(9).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.059855925299169957;  % kg
smiData.Solid(1).CoM = [0 50.28999999988266 0];  % mm
smiData.Solid(1).MoI = [74.968319902284421 4.8904057072354696 74.968319902287476];  % kg*mm^2
smiData.Solid(1).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(1).color = [0.89803921568627454 0.91764705882352937 0.92941176470588238];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'item_0037003_Profile_5_20x20_180*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.029784006617599973;  % kg
smiData.Solid(2).CoM = [0 19.999999999941611 0];  % mm
smiData.Solid(2).MoI = [10.151922595198698 2.4334412210493275 10.151922595200206];  % kg*mm^2
smiData.Solid(2).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(2).color = [0.89803921568627454 0.91764705882352937 0.92941176470588238];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'item_0037003_Profile_5_20x20_L=60*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.040666919389810978;  % kg
smiData.Solid(3).CoM = [96.445754120630582 94.280162739128059 2.4999999999999982];  % mm
smiData.Solid(3).MoI = [234.35884734140819 94.302486565847914 328.49188840979849];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 112.69769552293948];  % kg*mm^2
smiData.Solid(3).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'tunnel*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.055155567810370294;  % kg
smiData.Solid(4).CoM = [0 139.99999999970808 0];  % mm
smiData.Solid(4).MoI = [415.91994486554364 4.5063726315728321 415.91994486554648];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(4).color = [0.85098039215686272 0.83921568627450982 0.85882352941176465];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'item_0037003_Profile_5_20x20_L=300*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.075641759948661333;  % kg
smiData.Solid(5).CoM = [0 0 42.600000000000001];  % mm
smiData.Solid(5).MoI = [46.437989267682163 46.437989267682163 1.3615516790759048];  % kg*mm^2
smiData.Solid(5).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(5).color = [0.65098039215686276 0.61960784313725492 0.58823529411764708];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'shaft*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.13092430304202785;  % kg
smiData.Solid(6).CoM = [0 0 0];  % mm
smiData.Solid(6).MoI = [51.963855877380858 51.963855877380858 51.963855877380865];  % kg*mm^2
smiData.Solid(6).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(6).color = [1 1 1];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'ball*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.0018385189270122952;  % kg
smiData.Solid(7).CoM = [0 -5.0000000000098304 0];  % mm
smiData.Solid(7).MoI = [0.090427201583562447 0.15021242105242485 0.09042720158365794];  % kg*mm^2
smiData.Solid(7).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(7).color = [0.85098039215686272 0.83921568627450982 0.85882352941176465];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'item_0037003_Profile_5_20x20_L=10*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.1083710933225277;  % kg
smiData.Solid(8).CoM = [-24.999999999999957 0 0];  % mm
smiData.Solid(8).MoI = [46.873646251578613 38.732488311615072 38.732488311615072];  % kg*mm^2
smiData.Solid(8).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(8).color = [0.29803921568627451 0.29803921568627451 0.29803921568627451];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'Wheel*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 0.17970080673624467;  % kg
smiData.Solid(9).CoM = [51.957194170232093 58.130619843051882 2.5];  % mm
smiData.Solid(9).MoI = [265.24551799433482 211.17969031330679 475.6764549462406];  % kg*mm^2
smiData.Solid(9).PoI = [0 0 94.238387715378863];  % kg*mm^2
smiData.Solid(9).color = [0.89803921568627454 0.91764705882352937 0.92941176470588238];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = 'wall*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the PlanarJoint structure array by filling in null values.
smiData.PlanarJoint(7).Rz.Pos = 0.0;
smiData.PlanarJoint(7).Px.Pos = 0.0;
smiData.PlanarJoint(7).Py.Pos = 0.0;
smiData.PlanarJoint(7).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(1).Rz.Pos = 0;  % deg
smiData.PlanarJoint(1).Px.Pos = 0;  % mm
smiData.PlanarJoint(1).Py.Pos = 0;  % mm
smiData.PlanarJoint(1).ID = '[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=300-2]';

smiData.PlanarJoint(2).Rz.Pos = 0;  % deg
smiData.PlanarJoint(2).Px.Pos = 0;  % mm
smiData.PlanarJoint(2).Py.Pos = 0;  % mm
smiData.PlanarJoint(2).ID = '[item_0037003_Profile_5_20x20_L=300-1:-:wall-1]';

smiData.PlanarJoint(3).Rz.Pos = 180;  % deg
smiData.PlanarJoint(3).Px.Pos = 0;  % mm
smiData.PlanarJoint(3).Py.Pos = 0;  % mm
smiData.PlanarJoint(3).ID = '[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_180-2]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(4).Rz.Pos = 0;  % deg
smiData.PlanarJoint(4).Px.Pos = 0;  % mm
smiData.PlanarJoint(4).Py.Pos = 0;  % mm
smiData.PlanarJoint(4).ID = '[item_0037003_Profile_5_20x20_L=300-2:-:wall-2]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(5).Rz.Pos = -1.7127811137784224e-14;  % deg
smiData.PlanarJoint(5).Px.Pos = 0;  % mm
smiData.PlanarJoint(5).Py.Pos = 0;  % mm
smiData.PlanarJoint(5).ID = '[item_0037003_Profile_5_20x20_L=10-3:-:item_0037003_Profile_5_20x20_L=10-4]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(6).Rz.Pos = -89.999999999999815;  % deg
smiData.PlanarJoint(6).Px.Pos = 0;  % mm
smiData.PlanarJoint(6).Py.Pos = 0;  % mm
smiData.PlanarJoint(6).ID = '[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=60-3]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(7).Rz.Pos = 90.000000000000199;  % deg
smiData.PlanarJoint(7).Px.Pos = 0;  % mm
smiData.PlanarJoint(7).Py.Pos = 0;  % mm
smiData.PlanarJoint(7).ID = '[item_0037003_Profile_5_20x20_L=60-3:-:item_0037003_Profile_5_20x20_180-1]';


%Initialize the PrismaticJoint structure array by filling in null values.
smiData.PrismaticJoint(6).Pz.Pos = 0.0;
smiData.PrismaticJoint(6).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PrismaticJoint(1).Pz.Pos = 0;  % m
smiData.PrismaticJoint(1).ID = '[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_180-1]';

smiData.PrismaticJoint(2).Pz.Pos = 0;  % m
smiData.PrismaticJoint(2).ID = '[item_0037003_Profile_5_20x20_180-1:-:item_0037003_Profile_5_20x20_180-2]';

smiData.PrismaticJoint(3).Pz.Pos = 0;  % m
smiData.PrismaticJoint(3).ID = '[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_L=10-3]';

smiData.PrismaticJoint(4).Pz.Pos = 0;  % m
smiData.PrismaticJoint(4).ID = '[item_0037003_Profile_5_20x20_L=300-1:-:item_0037003_Profile_5_20x20_L=10-4]';

smiData.PrismaticJoint(5).Pz.Pos = 0;  % m
smiData.PrismaticJoint(5).ID = '[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_L=60-2]';

smiData.PrismaticJoint(6).Pz.Pos = 0;  % m
smiData.PrismaticJoint(6).ID = '[item_0037003_Profile_5_20x20_L=300-2:-:item_0037003_Profile_5_20x20_L=60-3]';


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(2).Rz.Pos = 0.0;
smiData.RevoluteJoint(2).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(1).ID = '[wall-1:-:shaft-1]';

smiData.RevoluteJoint(2).Rz.Pos = 9.1229028265154017;  % deg
smiData.RevoluteJoint(2).ID = '[wall-1:-:shaft-2]';

